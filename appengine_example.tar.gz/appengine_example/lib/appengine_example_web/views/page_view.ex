defmodule AppengineExampleWeb.PageView do
  use AppengineExampleWeb, :view
end
