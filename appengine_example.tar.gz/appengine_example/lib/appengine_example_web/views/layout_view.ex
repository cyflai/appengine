defmodule AppengineExampleWeb.LayoutView do
  use AppengineExampleWeb, :view
end
