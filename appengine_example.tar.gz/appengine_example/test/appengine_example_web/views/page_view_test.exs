defmodule AppengineExampleWeb.PageViewTest do
  use AppengineExampleWeb.ConnCase, async: true
end
