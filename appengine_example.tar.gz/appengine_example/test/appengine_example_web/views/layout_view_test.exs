defmodule AppengineExampleWeb.LayoutViewTest do
  use AppengineExampleWeb.ConnCase, async: true
end
